### [Unreleased]

### [3.0.0-beta.5] - 2022-03-29

- New: DNS public IP method
- New: Handle a list of public IP methods
- Change: Rust 1.57 to 1.59
- Change: Backoff retry seconds reduced for the first and second retry.

### [3.0.0-beta.4] - 2022-01-12

- New: cargo deny
- Change: IP method `aws` renamed to `aws-metadata`
- Change: Rust 1.56 to 1.57
- Change: Clap 3 out of beta

### [3.0.0-beta.3] - 2021-12-14

- New: Import config from noip2
- Change: static builds

### [3.0.0-beta.2] - 2021-11-02

- Change: Rust 1.53 to 1.56

### [3.0.0-beta.1] - 2021-07-07

- Initial write, everything working.
